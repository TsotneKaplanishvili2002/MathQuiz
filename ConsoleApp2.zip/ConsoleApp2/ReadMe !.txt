Program Name: Math Test

The program automatically generates an example to which the user must give the correct answer. At first, the program asks the user how many question tests he wants to run, we have a total of three sections (10 points, 20 points, and 30 points), and when the user has finished the number of questions, the program automatically tells him how many correct answers he had in total and how much time he spent on this test.

ქართლად: 

პროგრამის სახელი: მათემატიკის ტესტი

პროგრამა ავტომატურად აგენერირებს მაგალითს, რომელზეც მომხმარებელმა უნდა გასცეს სწორი პასუხი. თავდაპირველად პროგრამა ეკითხება მომხმარებელს თუ რამდენ შეკითხვიანი ტესტი სურს რომ გაუშვას, გვაქვს სულ სამი დანაყოფი ( 10 ქულიანი 20 ქულიანი და 30 ქულიანი ), როდესაც უკვე მომხმარებელი დაასრულებს შეკითხვების რაოდენობას პროგრამა ავტომატურად ეუბნება თუ რამდენი სწორი პასუხი ქონდა მას ჯამში დაგროვებული და რა დრო მოანდომა მან ამ ტესტის დაწერას.