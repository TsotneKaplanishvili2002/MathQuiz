﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many questions would you like to answer? (10, 20, or 30)");
            int numQuestions;
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "10" || input == "20" || input == "30")
                {
                    numQuestions = int.Parse(input);
                    break;
                }
                Console.WriteLine("Invalid input. Please enter 10, 20, or 30.");
            }

            int maxValue = 10;

            int score = 0;
            TimeSpan totalTime = TimeSpan.Zero;

            for (int i = 1; i <= numQuestions; i++)
            {
                Random rand = new Random();
                int operand1 = rand.Next(maxValue + 1);
                int operand2 = rand.Next(maxValue + 1);
                char op = rand.Next(2) == 0 ? '+' : '-';

                Console.Write($"{i}. {operand1} {op} {operand2} = ");
                DateTime startTime = DateTime.Now;
                int answer = int.Parse(Console.ReadLine());
                TimeSpan questionTime = DateTime.Now - startTime;

                int expected = op == '+' ? operand1 + operand2 : operand1 - operand2;
                if (answer == expected)
                {
                    Console.WriteLine("Correct!");
                    score++;
                }
                else
                {
                    Console.WriteLine($"Incorrect. The correct answer is {expected}.");
                }
                totalTime += questionTime;
            }

            Console.WriteLine($"You scored {score} out of {numQuestions}.");
            Console.WriteLine($"Total time: {totalTime.TotalSeconds:0.00} seconds.");

            Console.ReadLine();
        }
    }
}
